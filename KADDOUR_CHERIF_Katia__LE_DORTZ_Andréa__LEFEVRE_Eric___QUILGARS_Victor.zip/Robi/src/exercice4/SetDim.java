package exercice4;

import java.awt.Dimension;

import graphicLayer.GRect;
import stree.parser.SNode;

public class SetDim implements Command {
    
    public Reference run(Reference reference, SNode method) {
    	
    	if (method.size() != 4) {
    		throw new Error("Incorrect number of arguments");
    	}
    	
    	int dx = Integer.parseInt(method.get(2).contents());;
        int dy = Integer.parseInt(method.get(3).contents());;
        
        if (reference.receiver instanceof GRect) {
			GRect target = (GRect) reference.receiver;
			target.setDimension(new Dimension(dx, dy));
		}
        
        return null;
    }
}
