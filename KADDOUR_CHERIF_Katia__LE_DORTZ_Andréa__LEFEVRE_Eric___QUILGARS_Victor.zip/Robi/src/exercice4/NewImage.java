package exercice4;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.imageio.ImageIO;

import graphicLayer.GElement;
import stree.parser.SNode;

public class NewImage implements Command {

	//Cree une nouvelle reference avec des commandes elementaires et le retourne
	public Reference run(Reference reference, SNode method) {
		try {
			if (method.size() != 3) {
	    		throw new Error("Incorrect number of arguments");
	    	}
			
			String imageName = method.get(2).contents();
			BufferedImage image = ImageIO.read(new File(imageName));
			
			@SuppressWarnings("unchecked")
			//Instancie l'element e à partir du receiver de type exemple.class
			GElement e = ((Class<GElement>) reference.getReceiver()).getDeclaredConstructor(Image.class).newInstance((Image) image);
			//Referencie le nouvel objet et ajoute les fonctions de base
			Reference ref = new Reference(e);
			ref.addCommand("setColor", new SetColor());
			ref.addCommand("translate", new Translate());
			ref.addCommand("setDim", new SetDim());
			return ref;
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException | IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
