package exercice4;

import graphicLayer.GElement;
import graphicLayer.GSpace;
import stree.parser.SNode;

public class DelElement implements Command {

	Environment environment;

	public DelElement(Environment environment) {
		this.environment = environment;
	}
	
	//Supprime le GElement specifie de l'environment 
	@Override
	public Reference run(Reference reference, SNode method) {
		
		if (method.size() != 3) {
    		throw new Error("Incorrect number of arguments");
    	}
    	
        if (reference.receiver instanceof GSpace) {
        	GSpace target = (GSpace) reference.receiver;
            
            Reference objectToRemove = environment.getReferenceByName(method.get(2).contents());
            GElement elementToRemove = (GElement) objectToRemove.receiver;
            target.removeElement(elementToRemove);
            target.repaint();
        }

        return null;
	}

}
