package exercice4;

import java.awt.Color;

import graphicLayer.GElement;
import graphicLayer.GSpace;
import stree.parser.SNode;

public class SetColor implements Command {

	public Reference run(Reference reference, SNode method) {
		
		if (method.size() != 3) {
    		throw new Error("Incorrect number of arguments");
    	}
		
		Color c = this.getColorFromName(method.get(2).contents());
		
		if (c == null) {
			throw new Error("Unknown Color");
		}
		
		if (reference.receiver instanceof GElement) {
			GElement target = (GElement) reference.receiver;
			target.setColor(c);
		}
		if (reference.receiver instanceof GSpace) {
			GSpace target = (GSpace) reference.receiver;
			target.setColor(c);
		}

		return null;
	}
	
	private Color getColorFromName(String colorName) {
        switch (colorName) {
            case "black":
                return Color.BLACK;
            case "yellow":
                return Color.YELLOW;
            case "white":
                return Color.WHITE;
            case "red":
                return Color.RED;
            default:
                return null;
        }
    }

}
