package exercice4;

import stree.parser.SNode;

public class Sleep implements Command {

	public Reference run(Reference reference, SNode method) {
		
		if (method.size() != 3) {
    		throw new Error("Incorrect number of arguments");
    	}
		
		int sleepTime = Integer.parseInt(method.get(2).contents());
		
		try {
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

		return null;
	}
}
