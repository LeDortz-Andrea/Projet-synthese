package exercice1;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Color;
import java.util.Random;
import graphicLayer.GRect;
import graphicLayer.GSpace;

public class Exercice1_0 {
    GSpace space = new GSpace("Exercice 1", new Dimension(200, 150));
    GRect robi = new GRect();

    public Exercice1_0() {
        space.addElement(robi);
        space.open();
        animateRobi();
    }

    private void animateRobi() {
        while (true) {
            // Position initiale de robi
            Point position = new Point(0, 0);

            while (true) {
                // Déplacement jusqu'au bord droit
                while (position.x < space.getWidth() - robi.getWidth()) {
                    position.translate(1, 0); // Déplacement à droite
                    robi.setPosition(position);
                    space.repaint();
                    waitForAnimation();
                }

                // Déplacement jusqu'au bord bas
                while (position.y < space.getHeight() - robi.getHeight()) {
                    position.translate(0, 1); // Déplacement vers le bas
                    robi.setPosition(position);
                    space.repaint();
                    waitForAnimation();
                }

                // Déplacement jusqu'au bord gauche
                while (position.x > 0) {
                    position.translate(-1, 0); // Déplacement à gauche
                    robi.setPosition(position);
                    space.repaint();
                    waitForAnimation();
                }

                // Déplacement jusqu'au bord haut
                while (position.y > 0) {
                    position.translate(0, -1); // Déplacement vers le haut
                    robi.setPosition(position);
                    space.repaint();
                    waitForAnimation();
                }

                // Changement de couleur de robi avec une couleur aléatoire
                Random rand = new Random();
                Color randomColor = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
                robi.setColor(randomColor);
                space.repaint();
            }
        }
    }


    private void waitForAnimation() {
        try {
            Thread.sleep(10); // Pause de 10 millisecondes entre chaque étape de l'animation
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Exercice1_0();
    }
}