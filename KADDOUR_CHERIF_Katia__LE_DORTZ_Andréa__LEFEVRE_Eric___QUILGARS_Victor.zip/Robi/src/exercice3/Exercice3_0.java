package exercice3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import graphicLayer.GRect;
import graphicLayer.GSpace;
import stree.parser.SNode;
import stree.parser.SParser;

public class Exercice3_0 {
	GSpace space = new GSpace("Exercice 3", new Dimension(200, 100));
	GRect robi = new GRect();
	String script = "" +
	"   (space setColor black) " +
	"   (robi setColor yellow)" +
	"   (space sleep 1000)" +
	"   (space setColor white)\n" + 
	"   (space sleep 1000)" +
	"	(robi setColor red) \n" + 
	"   (space sleep 1000)" +
	"	(robi translate 100 0)\n" + 
	"	(space sleep 1000)\n" + 
	"	(robi translate 0 50)\n" + 
	"	(space sleep 1000)\n" + 
	"	(robi translate -100 0)\n" + 
	"	(space sleep 1000)\n" + 
	"	(robi translate 0 -40)";

	public Exercice3_0() {
		space.addElement(robi);
		space.open();
		this.runScript();
	}

	private void runScript() {
		SParser<SNode> parser = new SParser<>();
		List<SNode> rootNodes = null;
		try {
			rootNodes = parser.parse(script);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Iterator<SNode> itor = rootNodes.iterator();
		while (itor.hasNext()) {
			this.run(itor.next());
		}
	}

	private void run(SNode expr) {
		Command cmd = getCommandFromExpr(expr);
		if (cmd == null)
			throw new Error("unable to get command for: " + expr);
		cmd.run();
	}

	Command getCommandFromExpr(SNode expr) {
		String target = expr.get(0).contents();
		
		// Execution des commandes relatives a l'espace
		if (target.equals("space")) {
			String cmd = expr.get(1).contents();
			
			if (cmd.equals("setColor")) {
				return new SpaceChangeColor(getColorFromName(expr.get(2).contents()));
				
			} else if (cmd.equals("sleep")) {
				return new SpaceSleep(Integer.parseInt(expr.get(2).contents()));
				
			} else
				throw new Error("Invalid space command:" + expr);
		
		// Execution des commandes relatives a robi
		} else if (target.equals("robi")) {
			String cmd = expr.get(1).contents();
			
			if (cmd.equals("setColor")) {
				return new RobiChangeColor(getColorFromName(expr.get(2).contents()));
				
			} else if (cmd.equals("translate")) {
				return new RobiTranslate(Integer.parseInt(expr.get(2).contents()), Integer.parseInt(expr.get(3).contents()));
				
			} else {
				throw new Error("Invalid robi command:" + expr);
			}
		} else
			throw new Error("Unknown target in command: " + expr);
	}

	public static void main(String[] args) {
		new Exercice3_0();
	}

	public interface Command {
		abstract public void run();
	}

	public class SpaceChangeColor implements Command {
		Color newColor;

		public SpaceChangeColor(Color newColor) {
			this.newColor = newColor;
		}

		@Override
		public void run() {
			space.setColor(newColor);
		}

	}
	
	public class RobiChangeColor implements Command {
		Color newColor;
		
		public RobiChangeColor (Color newColor) {
			this.newColor = newColor;
		}
		
		@Override
		public void run() {
			robi.setColor(newColor);
		}
	}
	
	public class SpaceSleep implements Command {
		int sleepTime;

        public SpaceSleep(int sleepTime) {
            this.sleepTime = sleepTime;
        }
		
		@Override
        public void run() {
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
	}
	
	public class RobiTranslate implements Command {
        private int dx;
        private int dy;

        public RobiTranslate(int dx, int dy) {
            this.dx = dx;
            this.dy = dy;
        }

        @Override
        public void run() {
            robi.translate(new Point(dx, dy));
        }
    }
	
	private Color getColorFromName(String colorName) {
        switch (colorName) {
            case "black":
                return Color.BLACK;
            case "yellow":
                return Color.YELLOW;
            case "white":
                return Color.WHITE;
            case "red":
                return Color.RED;
            default:
                return null;
        }
    }
}