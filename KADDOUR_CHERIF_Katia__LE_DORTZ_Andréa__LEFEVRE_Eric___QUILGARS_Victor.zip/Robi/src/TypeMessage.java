
public enum TypeMessage {
	NULL, 
	SEND,
	PAS, 
	BLOC,
	REPONSE,
	CLEAR
}
