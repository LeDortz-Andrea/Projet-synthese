package exercice2;

import java.awt.*;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import graphicLayer.GRect;
import graphicLayer.GSpace;
import stree.parser.SNode;
import stree.parser.SParser;


public class Exercice2_1_0 {
	GSpace space = new GSpace("Exercice 2_1", new Dimension(200, 100));
	GRect robi = new GRect();
	String script = "(space setColor white)\n"
			+ "      (space sleep 1000)\n"
			+ "      (robi setColor red)\n"
			+ "      (robi translate 10 0)\n"
			+ "      (space sleep 1000)\n"
			+ "      (robi translate 0 10)\n"
			+ "      (space sleep 1000)\n"
			+ "      (robi translate -10 0)\n"
			+ "      (space sleep 1000)\n"
			+ "      (robi translate 0 -10)";

	public Exercice2_1_0() {
		space.addElement(robi);
		space.open();
		this.runScript();
	}

	private void runScript() {
		SParser<SNode> parser = new SParser<>();
		List<SNode> rootNodes = null;
		try {
			rootNodes = parser.parse(script);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Iterator<SNode> itor = rootNodes.iterator();
		while (itor.hasNext()) {
			this.run(itor.next());
		}
	}
	
	private void run(SNode expr) {
	    String leaf0 = expr.get(0).contents();
	    String leaf1 = expr.get(1).contents();
	    String leaf2 = expr.get(2).contents();
	    
	    //si le script concerne robi 
	    if (leaf0.equals("robi")) {
	    	//si l'action sur le robi concerne un changement de couleur
	        if (leaf1.equals("setColor")) {
	        	//on recupere la couleur avc le nom 
	            Color c = getColorFromName(leaf2);
	        	//si la couleur existe 
	            if (c != null) {
	                robi.setColor(c);
	            } else {
	                System.err.println("Unknown color: " + leaf2);
	            }
	            //si l'action sur le robi est un translate 
	        } else if (leaf1.equals("translate")) {
	        	//si le nombre de param est le bon 
	            if (expr.size() == 4) {
	            	//on recup le derier param 
	                String leaf3 = expr.get(3).contents();
	                //verif si les 2 derniers param ont un bon pattern 
	                if (leaf2.matches("-?\\d+") && leaf3.matches("-?\\d+")) {
	                	//on fait un nouveau points avec les nouvelles positions 
	                    Point p = new Point(Integer.parseInt(leaf2), Integer.parseInt(leaf3));
	                    //on fait le translate
	                    robi.translate(p);
	                } else {
	                    System.err.println("Invalid integer format in translation parameters.");
	                }
	            } else {
	                System.err.println("Insufficient parameters for translation.");
	            }
	        } else {
	            System.err.println("Unknown command for robi: " + leaf1);
	        }
	        //si le script concerne le space 
	    } else if (leaf0.equals("space")) {
	    	//si l'action est un changement de couleur
	    	if (leaf1.equals("setColor")) {
	            //on prend la couleur en fonction du nom
	    		 Color c = getColorFromName(leaf2);
	            if (c != null) {
	                space.setColor(c);
	            } else {
	                System.err.println("Unknown color: " + leaf2);
	            }
	        }
	    	else {
	    		try {
		            Thread.sleep(Integer.parseInt(leaf2));
		        } catch (NumberFormatException | InterruptedException e) {
		            e.printStackTrace();
		        }
	    	}
	        
	    } else {
	        System.err.println("Unknown element: " + leaf0);
	    }
	}

	private Color getColorFromName(String colorName) {
        switch (colorName) {
            case "black":
                return Color.BLACK;
            case "yellow":
                return Color.YELLOW;
            case "white":
                return Color.WHITE;
            case "red":
                return Color.RED;
            case "blue" :
            	return Color.CYAN;
            default:
                return null;
        }
    }


	public static void main(String[] args) {
		new Exercice2_1_0();
	}

}
