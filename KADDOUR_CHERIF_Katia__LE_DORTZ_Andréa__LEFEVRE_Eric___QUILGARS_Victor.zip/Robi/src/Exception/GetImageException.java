package Exception;

public class GetImageException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GetImageException(String message) {
		super(message);
	}
}
