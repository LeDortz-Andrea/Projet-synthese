package Exception;

public class UnknownColorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
