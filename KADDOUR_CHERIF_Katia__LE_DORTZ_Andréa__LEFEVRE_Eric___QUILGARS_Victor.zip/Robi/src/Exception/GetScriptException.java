package Exception;

public class GetScriptException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GetScriptException(String message) {
		super(message);
	}
	
}
