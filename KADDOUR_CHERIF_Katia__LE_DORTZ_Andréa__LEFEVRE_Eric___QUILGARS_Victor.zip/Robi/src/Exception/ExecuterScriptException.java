package Exception;

public class ExecuterScriptException extends Exception {

	
	private static final long serialVersionUID = 5544430350962551922L;
	
	public ExecuterScriptException(String message) {
		super(message);
	}

}
