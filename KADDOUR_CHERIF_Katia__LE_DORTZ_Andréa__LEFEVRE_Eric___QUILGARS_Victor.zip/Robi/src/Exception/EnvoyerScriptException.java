package Exception;

public class EnvoyerScriptException extends Exception {

	private static final long serialVersionUID = 2276679946933060237L;

	public EnvoyerScriptException(String message) {
		super(message);
    }


}
