package Exception;

public class InvalidCommandArgumentsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
