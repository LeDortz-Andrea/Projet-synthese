package Exception;
import java.io.*;

public class ConnexionException extends IOException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5889632210474654082L;

	public ConnexionException(String message) {
		super(message);
    }

}

