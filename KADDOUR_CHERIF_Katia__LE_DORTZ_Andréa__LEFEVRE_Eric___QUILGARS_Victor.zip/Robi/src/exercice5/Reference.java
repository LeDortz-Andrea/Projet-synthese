package exercice5;

import java.util.HashMap;
import java.util.Map;

import stree.parser.SNode;

public class Reference {
	Object receiver;
	
	Map<String, Command> primitives;
	
	public Reference(Object receiver) {
		this.receiver = receiver;
		primitives = new HashMap<String, Command>();
	}

	public void run(SNode method) {
		Command cmd = this.getCommandByName(method.get(1).contents());
		
		if (cmd == null) {
			throw new Error("Invalid command:" + method);
		} 
		
		cmd.run(this, method);
		
	}
	
	// run specifically for "new" command
	public void run(SNode method, Environment environment, String name) {
		
		//new command
		Command cmd1 = this.getCommandByName(method.get(1).contents());
		
		if (cmd1 == null) {
			throw new Error("Invalid command:" + method);
		} 
		
		//L'objet name nouvellement cree est maintenant reference dans l'environment
		environment.addReference(name, cmd1.run(environment.getReferenceByName(method.get(0).contents()), method));
	
	}
	
	public Command getCommandByName(String selector) {
		Command c = primitives.get(selector);
		
		if (c == null) throw new Error("Command not found");
		
		return c;
	}
	
	public void addCommand(String selector, Command primitive) {
		primitives.put(selector, primitive);
	}

	public Object getReceiver() {
		
		return receiver;
	}
}
