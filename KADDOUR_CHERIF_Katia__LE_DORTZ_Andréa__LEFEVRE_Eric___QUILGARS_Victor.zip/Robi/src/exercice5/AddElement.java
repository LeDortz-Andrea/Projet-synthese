package exercice5;

import graphicLayer.GContainer;
import graphicLayer.GElement;
import stree.parser.SNode;

public class AddElement implements Command {
	
	Environment environment;

	public AddElement(Environment environment) {
		this.environment = environment;
	}
	
	@Override
	public Reference run(Reference reference, SNode method) {
		
		if (method.size() != 4) {
    		throw new Error("Incorrect number of arguments");
    	}
    	
        if (reference.receiver instanceof GContainer) {
        	GContainer target = (GContainer) reference.receiver;
            
        	String newObjectName = method.get(0).contents() + "." + method.get(2).contents();
            Reference objectToAdd = environment.getReferenceByName(newObjectName);
            GElement elementToAdd = (GElement) objectToAdd.receiver;
            target.addElement(elementToAdd);
            target.repaint();
        }

        return null;
	}

}
