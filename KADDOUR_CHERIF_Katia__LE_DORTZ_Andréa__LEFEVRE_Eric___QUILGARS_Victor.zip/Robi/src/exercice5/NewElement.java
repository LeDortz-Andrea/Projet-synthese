package exercice5;

import java.lang.reflect.InvocationTargetException;

import graphicLayer.GContainer;
import graphicLayer.GElement;
import stree.parser.SNode;

public class NewElement implements Command {

	Environment environment;

	public NewElement(Environment environment) {
		this.environment = environment;
	}

	public Reference run(Reference reference, SNode method) {
		try {
			if (method.size() != 2) {
	    		throw new Error("Incorrect number of arguments");
	    	}
			
			@SuppressWarnings("unchecked")
			//Instancie l'element e à partir du receiver de type exemple.class
			GElement e = ((Class<GElement>) reference.getReceiver()).getDeclaredConstructor().newInstance();
			//Referencie le nouvel objet et ajoute les fonctions de base
			Reference ref = new Reference(e);
			ref.addCommand("setColor", new SetColor());
			ref.addCommand("translate", new Translate());
			ref.addCommand("setDim", new SetDim());
			ref.addCommand("del", new DelElement(environment));
			if (ref.receiver instanceof GContainer) {
				ref.addCommand("add", new AddElement(environment));
			}
			return ref;
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		}
		return null;
	}	
}
