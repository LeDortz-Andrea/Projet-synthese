package exercice5;

 /*
(space setDim 150 120)
(space add robi (Rect new))
(space.robi setColor white)
(space.robi setDim 100 100)
(space.robi translate 20 10)
(space.robi add im (Image new alien.gif))
(space.robi.im translate 20 20)


(space del space.robi)
(space.robi del space.robi.im)

*/


import java.awt.Dimension;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import graphicLayer.GImage;
import graphicLayer.GOval;
import graphicLayer.GRect;
import graphicLayer.GSpace;
import graphicLayer.GString;
import stree.parser.SNode;
import stree.parser.SParser;
import tools.Tools;



public class Exercice5 {
	// Une seule variable d'instance
	Environment environment = new Environment();

	public Exercice5() {
		GSpace space = new GSpace("Exercice 4", new Dimension(200, 100));
		space.open();
		
		//on declare des references 
		Reference spaceRef = new Reference(space);
		Reference rectClassRef = new Reference(GRect.class);
		Reference ovalClassRef = new Reference(GOval.class);
		Reference imageClassRef = new Reference(GImage.class);
		Reference stringClassRef = new Reference(GString.class);

		//on ajoute des commandes a ces references 
		spaceRef.addCommand("setColor", new SetColor());
		spaceRef.addCommand("sleep", new Sleep());
		spaceRef.addCommand("setDim", new SetDim());
		spaceRef.addCommand("add", new AddElement(environment));
		spaceRef.addCommand("del", new DelElement(environment));
		
		rectClassRef.addCommand("new", new NewElement(environment));
		ovalClassRef.addCommand("new", new NewElement(environment));
		imageClassRef.addCommand("new", new NewImage());
		stringClassRef.addCommand("new", new NewString());

		//ajout des references a l'environnement
		environment.addReference("space", spaceRef);
		environment.addReference("Rect", rectClassRef);
		environment.addReference("Oval", ovalClassRef);
		environment.addReference("Image", imageClassRef);
		environment.addReference("Label", stringClassRef);
		
		//this.mainLoop();
	}
	
	private void mainLoop() {
		while (true) {
			// prompt
			System.out.print("> ");
			// lecture d'une serie de s-expressions au clavier (return = fin de la serie)
			String input = Tools.readKeyboard();
			// creation du parser
			SParser<SNode> parser = new SParser<>();
			// compilation
			List<SNode> compiled = null;
			try {
				compiled = parser.parse(input);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// execution des s-expressions compilees
			Iterator<SNode> itor = compiled.iterator();
			while (itor.hasNext()) {
				new Interpreter().compute(environment, itor.next());
			}
		}
	}
	//fonction principale qui execute le script
	public void mainLoop2(String script) {
		
			// prompt
			//System.out.print("> ");
			// lecture d'une serie de s-expressions au clavier (return = fin de la serie)
			//String input = Tools.readKeyboard();
			// creation du parser
			SParser<SNode> parser = new SParser<>();
			// compilation
			List<SNode> compiled = null;
			try {
				//on parse le script passe en param
				compiled = parser.parse(script);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// execution des s-expressions compilees
			Iterator<SNode> itor = compiled.iterator();
			while (itor.hasNext()) {
				new Interpreter().compute(environment, itor.next());
			}
		
	}
	
	public class Interpreter {
		
		public void compute(Environment environment, SNode expr) {
			
			String receiverName;
			Reference receiver;
			
			// Si commande d'ajout on execute d'abord le subnode "(exmeple.class new)"
			if (expr.get(1).contents().equals("add")) {

				SNode subNode = (SNode)expr.children().toArray()[3];
				String newObjectName = expr.get(0).contents() + "." + expr.get(2).contents();
				
				receiverName = subNode.get(0).contents();
				receiver = environment.getReferenceByName(receiverName);
				
				//Overload de run qui ajoute a l'environment l'objet cree
				receiver.run(subNode, environment, newObjectName);
			}
			
			receiverName = expr.get(0).contents();
			receiver = environment.getReferenceByName(receiverName);

			receiver.run(expr);
		}
		
	}

	public static void main(String[] args) {
		new Exercice5();
	}

}
